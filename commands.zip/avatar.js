const Discord = require("discord.js");

module.exports.run = async(bot, message, args) =>{
    let avatar = new Discord.RichEmbed()
    .setImage(message.author.avatarURL)
    .setTimestamp()
    .setColor('RANDOM')
    .setDescription(message.author + " here is your current avatar. It Looks Really FANCY!!! :wink:")
    message.delete().catch(O_o=>{})
    return message.author.send(avatar)
  }

  module.exports.help = {
  	name: "avatar",
  	description: "sends you your avatar( a.k.a your profile picture)"
  }