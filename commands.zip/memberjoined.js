const Discord = require("discord.js");

module.exports.run = async(bot, message, args) => {

}

module.exports.help = {
}
