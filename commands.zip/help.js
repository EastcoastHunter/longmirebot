const Discord = require("discord.js");
const moment = require("moment");
const config = require("../botconfig.json");

module.exports.run = async(bot, message, args) => {
	let prefix = config.prefix;
	const help = new Discord.RichEmbed()
	.setColor("RANDOM")
	.setThumbnail(message.author.avatarURL)
	.setTitle(`${bot.user.username}'s Help Command `)
	.setDescription("`<>` Means required `()` optional")
	.setFooter("(c)2019 • Hunter's Web Designs And Bot Support • Hunter L.#3037")
	.addField(`${prefix}userinfo`, `sends you user information`, true)
	.addField(`${prefix}botinfo`, `displays bot info`, true)
	.addField(`${prefix}serverinfo`,`displays servers information` ,true)
	.addField(`${prefix}uptime`,`displays the bots uptime` ,true)
    .addField(`${prefix}purge`,"purges a message `/purge <nummber>`" ,true)
    .addField(`${prefix}ping`, "Command comming soon",true)
    .addField(`${prefix}stats`, "Gives You the bot stats",true)
    .addField(`${prefix}embed`, "embeds a text",true)
    .addField(`${prefix}ownercmds`, `sends owner cmd help`, true)
    message.delete().catch(O_o=>{})
    message.author.send(help)
	message.channel.send(message.author + " ***Check*** your _Dm's_ for the help message!")
}

module.exports.help = {
	name: "help",
	description: "Displays this message"
}
