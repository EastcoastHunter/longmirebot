const Discord = require("discord.js");
const bot = new Discord.Client;

module.exports.run = async(bot, message, args) =>{
    let boticon = bot.user.displayAvatarURL;
    let botembed = new Discord.RichEmbed()
    .setDescription("Bot Information")
    .setColor("RANDOM")
    .setThumbnail(boticon)
    .setFooter("(c)2019 • Hunters Web Designs and Bot Support Company")
    .addField("Bot Name:", bot.user.username)
    .addField("Bot Created Date:", bot.user.createdAt)
    .addField("Server Count:", bot.guilds.size);
    
    message.delete().catch(O_o=>{});
    message.channel.send(botembed);
};

module.exports.help =  {
    name: "botinfo",
    description: "Shows bot info"
};
