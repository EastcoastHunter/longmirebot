const Discord = require("discord.js");
const config = require("../botconfig.json");
module.exports.run = async(bot, message, args) =>{
    message.channel.send(`Hoold on!`).then(m => {
    message.edit(`***🏓 Wew, finaly made it over the ~waves~ !\nPong!\nMessage edit time is ` + (m.createdTimestamp - message.createdTimestamp) + `ms, Discord API heartbeat is ` + Math.round(bot.ping) + `ms. \Wow I am still alive!***`);
    });
}

module.exports.help = {
	name: "Ping",
	description: "Sends the bots pinging status"
}