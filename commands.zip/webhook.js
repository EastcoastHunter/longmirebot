const Discord = require("discord.js");
const config = require("../botconfig.json")
module.exports.run = async(bot, message, args) => {
	const hook = new Discord.WebhookClient('560665796901208065', 'OS7uqEwY0btNBrn70KoCckjFo-8VWaudwwmXKIy4roxcqiXq8f7QNPquwj97xyA9HuqQ');
	const hookes = new Discord.WebhookClient('560669162544824320', 'wEFBSTfjXwS0lz8COEVKmqWsDNkX_KN0H31asKo5Ws1jbkRps99TPrBHPCzxDu2ugPwd');
	let prefix = config.prefix;
	let hooks = new Discord.RichEmbed()
	.setTitle(`Bots Owner`)
	.setColor("RANDOM")
	.setThumbnail(bot.avatarURL)
    .setFooter(`${prefix}help for more • Message By: ${bot.user.username}`)
	.setTimestamp()
	.addField("Owners Name:",`<@202563982349959168>`, true)
	.addField("Owners YouTube:","[click here](<https://m.youtube.com/channel/UCMAP4cqtGruBPKF8lvfxXAg>) to go to the youtube channel", true)
	.addField("Owners Twitch:","[click here](<https:/twitch.tv/midwest_hunter>) to go to the twitch channel", true)
	.addField("Why This webhook exist","I the owner made this webhook that way theres away for my loyal members to support me and to get my name around!", true)

	hook.send(hooks);
	hookes.send(hooks);
	hook.send(message.author + " You sent the bot owner info to, _**2 servers**_. Thank you!")
	hookes.send(message.author + " You sent the bot owner info to, _**2 servers**_. Thank you!")
}

module.exports.help ={
	name: "webhook",
	description: "webhook"
}
