const Discord = require("discord.js");
const moment = require("moment");
const m = require("moment-duration-format");
const duration = require("duration");
const ms = require("ms");
const config = require("../botconfig.json");

module.exports.run = async(bot, message, args) =>{
        let bicon = bot.user.displayAvatarURL;
	let sicon = message.guild.iconURL;
	let prefix = config.prefix;
        let totalSeconds = process.uptime();
        let realTotalSecs = Math.floor(totalSeconds % 60);
        let days = Math.floor((totalSeconds % 31536000) / 86400);
        let hours = Math.floor((totalSeconds / 3600) % 24);
        let mins = Math.floor((totalSeconds / 60) % 60);
        
	let uptime = new Discord.RichEmbed()
        .setTitle(`Bots Uptime`)
	.setColor("RANDOM")
	.setThumbnail(bicon)
        .setFooter(`${prefix}help for more • Message By: ${bot.user.username}`, `${sicon}`)
	.setTimestamp()
	.addField("**Days:**",`${days}`, true)
        .addField("**Hours:**", `${hours}`, true)
        .addField("**Minutes:**", `${mins}`, true)
        .addField("**Seconds:**", `${realTotalSecs}`, true)
	.addField(".............", "This ***uptime*** is out standing so far!", false);
	
        message.delete().catch(O_o=>{});
	message.channel.send(uptime)
}

module.exports.help =  {
    name: "uptime",
    description: "Gives bot uptime"
}
