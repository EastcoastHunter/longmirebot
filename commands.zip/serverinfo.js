const Discord = require("discord.js");

module.exports.run = async(bot, message, args) =>{
    let humans = message.guild.members.filter(m => !m.user.bot).size;
    let bots = message.guild.members.filter(m => m.user.bot).size;
	let sicon = message.guild.iconURL;
    let serverembed = new Discord.RichEmbed()
    .setDescription("Server Information")
    .setColor("RANDOM")
	.setThumbnail(sicon)
    .setFooter("(c)2019 •Hunters Web Designs and Bot Support Company")
    .addField("Name:", `${message.guild.name} (${message.guild.nameAcronym})`, true)
    .addField("Server Owner:", message.guild.owner.user.tag, true)
    .addField("Server Create Date:", message.guild.createdAt, true)
    .addField("Total Member Count:", message.guild.memberCount, true)
    .addField("Total Human Count:", `${humans}`, true)
    .addField("Total Bot Count:", `${bots}`, true)
    
    message.delete().catch(O_o=>{});
    message.channel.send(serverembed);
}

module.exports.help =  {
    name: "serverinfo",
    description: "Gathers Information about the server"
}
